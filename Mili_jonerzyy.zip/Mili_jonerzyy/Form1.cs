﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Mili_jonerzyy
{
    public partial class Form1 : Form
    {
        // quiz game variables
        int correctAnswer;
        int questionNumber = 1;
        int score;
        int percentage;
        int totalQuestions;
        public Form1()
        {
            InitializeComponent();
            askQuestion(questionNumber);
            totalQuestions = 8;
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void checkAnswerEvent(object sender, EventArgs e)
        {
            var senderObject = (Button)sender;
            int buttonTag = Convert.ToInt32(senderObject.Tag);
            if (buttonTag == correctAnswer)
            {
                score++;
            }
            if (questionNumber == totalQuestions)
            {
                // work out the percentage
                percentage = (int)Math.Round((double)(score * 100) / totalQuestions);
                MessageBox.Show(
                "Quiz Ended!" + Environment.NewLine +
                "You have answered " + score + " questions correctly." + Environment.NewLine +
                "Your total percentage is " + percentage + "%" + Environment.NewLine +
                "Click OK to play again"
                );
                score = 0;
                questionNumber = 0;
                askQuestion(questionNumber);
            }
            questionNumber++;
            askQuestion(questionNumber);
        }
        private void askQuestion(int qnum)
        {
            switch (qnum)
            {
                case 1:
                    pictureBox1.Image = Properties.Resources.legia;
                    lblQuestion.Text = "Najgorszy klub w ekstraklasie?";
                    button1.Text = "Legia Warszawa";
                    button2.Text = "Raków Częstochowa";
                    button3.Text = "Benfica Lizbona";
                    button4.Text = "Lech Poznań";
                    correctAnswer = 1;
                    break;
                case 2:
                    pictureBox1.Image = Properties.Resources.live;
                    lblQuestion.Text = "Co to za klub?";
                    button1.Text = "Leeds United";
                    button2.Text = "Liverpool";
                    button3.Text = "Memczester United";
                    button4.Text = "Everton";
                    correctAnswer = 2;
                    break;
                case 3:
                    pictureBox1.Image = Properties.Resources.polska;
                    lblQuestion.Text = "Jaki był wynik meczu Polska-Czechy?";
                    button1.Text = "wygraliśmy 2-0";
                    button2.Text = "nie obchodzi mnie banda przegrywów..";
                    button3.Text = "3-2 czesi :(";
                    button4.Text = "3-1 czesi :(";
                    correctAnswer = 4;
                    break;
                case 4:
                    pictureBox1.Image = Properties.Resources.mbappe;
                    lblQuestion.Text = "Kto to jest?";
                    button1.Text = "siuuu";
                    button2.Text = "Messi";
                    button3.Text = "Mekbeppe";
                    button4.Text = "Robercik";
                    correctAnswer = 3;
                    break;
                case 5:
                    pictureBox1.Image = Properties.Resources.piesek;
                    lblQuestion.Text = "Co to za rasa psa?";
                    button1.Text = "owczarek niemiecki";
                    button2.Text = "lew";
                    button3.Text = "labrador";
                    button4.Text = "buldog francuski";
                    correctAnswer = 1;
                    break;
                case 6:
                    pictureBox1.Image = Properties.Resources.pizza;
                    lblQuestion.Text = "Kiedy został wydany ten słynny zart?";
                    button1.Text = "4 luty";
                    button2.Text = "nie wiem chodz sie domyślam";
                    button3.Text = "1 kwietnia";
                    button4.Text = "3 czerwca";
                    correctAnswer = 3;
                    break;
                case 7:
                    pictureBox1.Image = Properties.Resources.wszolek;
                    lblQuestion.Text = "Kim jest pan ze zdjęcia?";
                    button1.Text = "Leeeeo Messi";
                    button2.Text = "Michał Kucharczyk";
                    button3.Text = "Paweł Wszołek";
                    button4.Text = "Artur Boruc";
                    correctAnswer = 3;
                    break;
                case 8:
                    pictureBox1.Image = Properties.Resources.jedynanadziesiec;
                    lblQuestion.Text = "Jak ci sie podobał kłiz?";
                    button1.Text = "we we 0/10";
                    button2.Text = "Miernota 4/10";
                    button3.Text = "E nawet nawet 7.5/10";
                    button4.Text = "11/10 kozacko B)";
                    correctAnswer = 4;
                    break;
            }
        }
    }
}

